<?php include("../header.php") ?> 
<!-- <link rel="stylesheet" href="signup.css"> -->
<?php 
    if(!isset($_SESSION['id'])){
        // header("Refresh:0; url=../main/main_article.php");
    }
?> 

<article>
    <div id="">
        <div class="wrap">
            <p>
                API를 활용하여 상품 목록을 불러옴
                <!-- API를 활용하여 상품 목록을 불러옴 -->
                <!-- 장바구니에 추가하는 기능을 추가 -->
            </p>
        </div>
    </div>
</article>




<?php include("../footer.php") ?>