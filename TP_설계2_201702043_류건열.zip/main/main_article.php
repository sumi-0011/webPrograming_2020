<?php include("../header.php") ?> 
 
<article class="main_article">
        <div class="parent_div wrap">
            <div class="three_div" id="first_div">
                <strong>S&G</strong>는 Shopping과 Game을 한 번에 즐길 수 있는 사이트 입니다.<br><br>
                누구든 쉽게 이용하고 이길 수 있는 Game 한 판만으로도 할인 쿠폰이 와르르!!!
                얼른 참여하시고 할인 쿠폰 받아가세요!
                <!-- 사이트 소개글 추후 구현 -->
            </div>
            <div class="three_div" id="second_div">
                냥냥
                <!-- best 상품 추후 구현 -->
            </div>
            <div class="three_div" id="third_div">
                냥냥
                <!-- 추후 구현 -->
            </div>
        </div>
    
</article>




<?php include("../footer.php") ?>