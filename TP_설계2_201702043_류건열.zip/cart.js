function moveToCart(){
    //상품을 카트에 담는 버튼을 클릭하면 장바구니에 추가되도록 구현
}

function moveFromCart(){
    //상품을 카트에서 제외하는 버튼을 클릭하면 장바구니에서 삭제되도록 구현
}

function pay(){
    //장바구니에 담은 물품을 구매하는 버튼을 클릭하면 구매가 되도록 구현
}