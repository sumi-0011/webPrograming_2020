    <footer>
        <div class="wrap">
        <div class="footer_main">
            <p>류건열</p>
            <p>대전광역시 유성구 대학로 99 컴퓨터융합학부</p>
            <p>Copyright (C) 2020 CNU All Rights Reserved.</p>
        </div>
        </div>
    </footer>
<script src="../all.js"></script>
</body>
</html>