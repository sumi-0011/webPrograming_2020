<!DOCTYPE html>
<html>
<body>
<h2>숫자 맞추기 게임</h2>
당신이 생각한 숫자를 컴퓨터가 맞추는 게임입니다.<br><br>

<?php
$userNumber = 10;                   // 당신이 생각하는 숫자를 넣으시오.
$opportunity = 15;
    $check = array();
    for($i = 1;$i<=15;$i++) {
        $random = rand(1,15);
        if(!isset($check[$random])) {
            $check[$random] = 1;
            $bol = numgame($random);
            if($bol){
                $opportunity = $i;
            break;
            }
        } 
        else {
            $i--;
        }
    }
    if($opportunity <= 15) {
        echo "Game opportunity : ".$opportunity." times";
    } 
    function numgame($random) {
        global $userNumber;
        echo "The Number is ".$random."<br>";
        if($userNumber == $random) {
            echo "correct<br>";
            return true;
        }
        else {
            echo "fail<br>";
            return false;
        }
    }
?>
</body>
</html>

