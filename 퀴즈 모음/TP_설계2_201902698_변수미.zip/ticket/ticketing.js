window.onload = function() {
    showTicketing();
    
}
//화면이 로드되면 실행되는 함수
function showTicketing() {
    // 화면이 로드되면 날짜를 선택하게 하고 
    //날짜를 선택하면 seleteDate함수를 호출해 
    //그 날짜에 진행하는 공연을 알려준다. 
    
}
function seleteDate() {
    // 날짜를 선택하면 그 날짜에 해당되는 공연을 나타내고
    // 공연이름과 정보 시간 가격등을 화면에 나타내준다. 
}
//좌석선택 버튼은 누르면 실행되는 함수
function click_seatBt() {
    // 현재 선택한 공연을 sesstion에 넣어 무슨 공연을 예매하는지 저장하고
    // 좌석을 선택하는 페이지로 이동한다. 
}