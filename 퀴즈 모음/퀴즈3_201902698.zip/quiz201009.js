let addBt = document.getElementById('addBt');

window.onload = function() {
    addBt.addEventListener("click", addList);
}
function addList() {
    var temp = document.createElement('li');
    var text = document.getElementById('textBox');
    var tNode = document.createTextNode(text.value);
    temp.appendChild(tNode);
    temp.addEventListener("click", changeFunction);
    document.getElementById('olist').appendChild(temp);
    document.getElementById('textBox').value = "";
}
function changeFunction(event) {
    var txt;
    var prom = prompt("삭제는 1, 수정은 2를 입력하세요", "");
    if ( prom == "") {
      txt = "번호를 입력하지 않으셨습니다.";
      alert(txt);
    } else if(prom == null) {
        txt = "취소되었습니다.";
        alert(txt);
    }else if(prom ==1) {
       
        document.getElementById('olist').removeChild(event.target);
    }else if(prom == 2) {
        //수정
        var t = prompt("변경할 내용을 입력하세요.", "");
       // var temp = document.createElement('li');
        var tNode = document.createTextNode(t);
      
        event.target.replaceChild(tNode, event.target.firstChild);
    }else {
        alert("번호를 잘못 입력하셨습니다.");
    }
  }
 