// 상품 장바구니 입력 버튼
let cartIconBt = document.getElementById("shopping_cart_icon");
let modal = document.getElementById("input_window_modal");
let submitBt = document.getElementById("cart_in");
let cancelBt = document.getElementById("cart_in_close");

// table = 일반배송
let table_normal = document.getElementById("shopping_table_normal");
let tbody_normal = document.getElementById("normal_tbody");
let allcheckBox_normal = document.getElementById("normalAllCheck");
let selectDeleteBt_normal = document.getElementById("select_delete_normal");
let moveDawn = document.getElementById("moveDawn");
let checkboxCollection_normal = document.getElementsByClassName("normalCheck");

// table = 새벽배송
let table_dawn = document.getElementById("shopping_table_dawn");
let tbody_dawn = document.getElementById("dawn_tbody");
let allcheckBox_dawn = document.getElementById("dawnAllCheck");
let selectDeleteBt_dawn = document.getElementById("selete_delete_dawn");
let moveNormal = document.getElementById("moveNormal");
let checkboxCollection_dawn = document.getElementsByClassName("dawnCheck");

//****************(3)영역 ********************* */
let searchBt = document.getElementById("searchBt");
let searchResetBt = document.getElementById("searchResetBt");

window.onload = function () {


  /****************(1) 영역 input_madal ********************/

  cartIconBt.addEventListener("click", display_inputModal);
  cancelBt.addEventListener("click", displayNone_inputModal);
  submitBt.addEventListener("click", validator); //onclick 이 아닌 click이벤트
  //firstReset();
  /****************(2) 영역 table***************************/
  //전체 선택 checkbox
  allcheckBox_normal.addEventListener("click", allcheck_normal);
  allcheckBox_dawn.addEventListener("click", allcheck_dawn);
  //선택 삭제 버튼
  selectDeleteBt_normal.addEventListener("click", selectDeleteNormal);
  selectDeleteBt_dawn.addEventListener("click", selectDeleteDawn);
  // 배송방법 바꾸기 방법
  moveDawn.addEventListener("click", moveToDawn);
  moveNormal.addEventListener("click", moveToNormal);
  /****************(3) 영역 search***************************/
  searchBt.addEventListener("click", searchProduct);
  searchResetBt.addEventListener("click", searchReset);
};
function eventListenerAdd() {
  for (i of checkboxCollection_normal) {
    i.addEventListener("change", check_change);
  }
  for (i of checkboxCollection_dawn) {
    i.addEventListener("change", check_change);
  }
}
// (3) 영역 함수
function searchProduct() {
  var targetName = document.querySelector("#searchTargetName").value; //1469
  var targetpriceUp = document.querySelector("#searchTargetPriceUp").value; //3489
  var targetpriceDown = document.querySelector("#searchTargetPriceDown").value; //5689

  var result = "";
  if (targetName != "" && targetpriceUp != "" && targetpriceDown != "") {
    result = "9";
    search(targetName, targetpriceUp, targetpriceDown, result);
  } else if (targetName != "" && targetpriceUp != "") {
    result = "49";
    search(targetName, targetpriceUp, targetpriceDown, result);
  } else if (targetName != "" && targetpriceDown != "") {
    result = "96";
    search(targetName, targetpriceUp, targetpriceDown, result);
  } else if (targetName != "") {
    result = "9461";
    search(targetName, targetpriceUp, targetpriceDown, result);
  } else if (targetpriceUp != "" && targetpriceDown != "") {
    result = "98";
    search(targetName, targetpriceUp, targetpriceDown, result);
  } else if (targetpriceUp != "") {
    result = "9483";
    search(targetName, targetpriceUp, targetpriceDown, result);
  } else if (targetpriceDown != "") {
    result = "9685";
    search(targetName, targetpriceUp, targetpriceDown, result);
  }

  //빈칸으로
  // document.querySelector("#searchTargetName").value = "";
  // document.querySelector("#searchTargetPriceUp").value = "";
  // document.querySelector("#searchTargetPriceDown").value = "";
}

function search(targetName, targetUp, targetDown, result) {
  var list = document.querySelectorAll(".searchNoTr");
  for (element of list) {
    var name = element.querySelector(".nameClass").innerHTML;
    var price = element.querySelector(".priceClass").innerHTML;
    price = parseInt(price);
    var count = 0;
    //name검사
    if (name.indexOf(targetName) != -1) {
      count += 1;
    }
    //priceUp검사
    if (price >= parseInt(targetUp)) {
      count += 3;
    }
    if (price <= parseInt(targetDown)) {
      count += 5;
    }
    //console.log(name +" "+price+ " => count : "+count);

    if (result.indexOf(count) != -1) {
      element.className = "searchTr";
    }
  }
}
// var temp
function searchReset() {
  var c = document.querySelectorAll(".searchTr");
  for (element of c) {
    element.className = "searchNoTr";
  }
}

// (1) 영역 함수
//madal을 보이게
function display_inputModal() {
  modal.style.display = "block";
} //취소버튼을 누르면 modal를 안보이게 하고 초기화
function displayNone_inputModal() {
  modal.style.display = "none";
  cartInputReset();
} //초기화 함수
function cartInputReset() {
  document.getElementById("cart_input_form").reset();
}
// function firstReset() {
//   var cartIn_form = document.cart_input;
//   cartIn_form.product_name.value = "aa";
//   cartIn_form.product_price.value = 2000;
//   cartIn_form.product_amount.value = 30;
//   cartIn_form.delivery.value = "normal_delivery";
//   display_inputModal();
//   document.querySelector("#searchTargetName").value = "aa1";
//   document.querySelector("#searchTargetPriceUp").value = 2000;
//   document.querySelector("#searchTargetPriceDown").value = 2999;
// }

function validator() {
  var cartIn_form = document.cart_input;
  var image_file = cartIn_form.files;
  var name = cartIn_form.product_name.value;
  var price = cartIn_form.product_price.value;
  var num = cartIn_form.product_amount.value;
  var radioBt = cartIn_form.delivery.value;

  var check_validator = 0;
  console.log(image_file.value);
  if(image_file.value=="") {
    alert('상품 이미지를 추가하시오.');
  }
  else if (!chk_file_type(image_file)) {
    check_validator++;
  } //상품 이름 유효성검사
  if (!chk_productName_validator(name)) {
    check_validator++;
  } //상품 가격 유효성 검사
  if (!chk_productPrice_validator(price)) {
    check_validator++;
  } //상품 갯수 유효성 검사
  if (!chk_productNum_validator(num)) {
    check_validator++;
  } //배송방법 유효성 검사
  if (!chk_productRadio_validator(radioBt)) {
    check_validator++;
  }

  if (check_validator === 0) {
   
    inputCart();
    cartInputReset();
    modal.style.display = "none";
  
  } 
  //다른 함수에 넣어야 하나?
}
 
//유효성 검사 함수
function chk_productName_validator(name) {
  if (!name) {
    alert("상품 이름을 입력하시오.");
    return false;
  } else if (!isNaN(name)) {
    alert("문자로된 상품 이름을 입력하세요.");
    return false;
  }
  return true;
}
function chk_productPrice_validator(price) {
  if (!price) {
    alert("상품 가격을 입력하시오.");
    return false;
  } else if (isNaN(price)) {
    alert("상품 가격에 숫자를 입력하시오.");
    return false;
  } else if (price < 1000) {
    alert("상품 가격을 1000원 이상으로 입력하시오.");
    return false;
  } else {
    return true;
  }
}
function chk_productNum_validator(num) {
  if (!num) {
    alert("상품 개수를 입력하시오.");
    return false;
  } else if (isNaN(num)) {
    alert("상품 갯수에 숫자를 입력하시오.");
    return false;
  } else if (num == 0 || num > 50) {
    alert("최대 50개 이하로 선택하시오.");
    return false;
  }
  return true;
}
function chk_productRadio_validator(radioBt) {
  if (!radioBt) {
    alert("배송 방법을 선택하시오");
    return false;
  }
  return true;
}
function chk_file_type(obj) {
  var file_kind = obj.value.lastIndexOf(".");
  var file_name = obj.value.substring(file_kind + 1, obj.length); //파일 형식
  var file_type = file_name.toLowerCase();
  var check_file_type = new Array();
  check_file_type = ["jpg", "png", "jpeg"];

  if (check_file_type.indexOf(file_type) == -1) {
    alert(
      "이미지 화일이 아닙니다. 'jpg','jpeg' 또는 'png'을 확장자로 가진 화일을 추가하시오. "
    );
    var parent_Obj = obj.parentNode;
    var node = parent_Obj.replaceChild(obj.cloneNode(true), obj);

    // document.getElementById("wfb-field-219958876").value = ""; //초기화를 위한 추가 코드
    // document.getElementById("wfb-field-219958876").select(); //초기화를 위한 추가 코드
    // document.selection.clear(); //일부 브라우저 미지원
    return false;
  }
  return true;
}

// (2) 영역 함수
function inputCart() {
  var cartIn_form = document.cart_input;

  //table에 넣어줄 입력값들
  var name = cartIn_form.product_name.value;
  var price = cartIn_form.product_price.value;
  var num = cartIn_form.product_amount.value;
  var radioBt = cartIn_form.delivery.value;

  //error 
  //이미지 파일 경로 찾기
  var image_file = cartIn_form.files;
  var file_numStart = image_file.value.lastIndexOf("\\");
  var fileName = image_file.value.substring(file_numStart+1,image_file.length);

  //console.log(fileName);
  var trElement = document.createElement("tr");
  var td_checkbox = document.createElement("td");
  var td_img = document.createElement("td");
  var td_name = document.createElement("td");
  var td_price = document.createElement("td");
  var td_num = document.createElement("td");
  var td_totalNum = document.createElement("td");

  //error 수정해야함
  trElement.className = "searchNoTr";
  td_img.innerHTML ='<img src="./'+fileName + '" alt="image" width="80px" height="80px">';
  td_name.innerHTML = '<span class = "nameClass">' + name + "</span>";
  td_price.innerHTML = '<span class= "priceClass">' + price + "</span>";
  td_num.innerHTML = "<span>" + num + "</span>";
  td_totalNum.innerHTML = "<span>" + num * price + "</span>";

  //tr Element에 td 추가

  //console.log(trElement);
  if (radioBt == "normal_delivery") {
    td_checkbox.innerHTML =
      '<input type="checkbox" name="check" class="normalCheck" checked>';
    trElement.appendChild(td_checkbox);
    trElement.appendChild(td_img);
    trElement.appendChild(td_name);
    trElement.appendChild(td_price);
    trElement.appendChild(td_num);
    trElement.appendChild(td_totalNum);
    document.getElementById("normal_tbody").appendChild(trElement);
  } else {
    td_checkbox.innerHTML =
      '<input type="checkbox" name="check" class="dawnCheck" checked>';
    trElement.appendChild(td_checkbox);
    trElement.appendChild(td_img);
    trElement.appendChild(td_name);
    trElement.appendChild(td_price);
    trElement.appendChild(td_num);
    trElement.appendChild(td_totalNum);
    document.getElementById("dawn_tbody").appendChild(trElement);
  }
  //검시?
  //all 체크박스 체크여부 확인
  check_change();
  eventListenerAdd();
}
//allcheck 검사
function check_change() {
  //체크된 상품에 대해서만 구매가격들이 합산되어 나타남 -4번 !
  if (checkboxCollection_normal.length != 0) {
    Normal_check();
    Normal_product();
  } else {
    allcheckBox_normal.checked = false;
  }
  if (checkboxCollection_dawn.length != 0) {
    Dawn_check();
    Dawn_product();
  } else {
    allcheckBox_dawn.checked = false;
  }
}
function Normal_check() {
  //allcheckBox_normal 는 HTMLCOLLECTION이므로 for of 문 사용 (열거가능)
  var all = true;
  for (var element of checkboxCollection_normal) {
    if (!element.checked) {
      allcheckBox_normal.checked = false;
      all = false;
    }
  }
  if (all == true) {
    allcheckBox_normal.checked = true;
  }
}
function Dawn_check() {
  //allcheckBox_normal 는 HTMLCOLLECTION이므로 for of 문 사용 (열거가능)
  var all = true;
  for (var element of checkboxCollection_dawn) {
    if (!element.checked) {
      allcheckBox_dawn.checked = false;
      all = false;
    }
  }
  if (all == true) {
    allcheckBox_dawn.checked = true;
  }
}
function Normal_product() {
  var price_sum = 0;
  for (var element of checkboxCollection_normal) {
    var elePrice =
      element.parentNode.parentNode.children[5].firstElementChild.innerHTML;
    if (element.checked) {
      price_sum += parseInt(elePrice);
    }
  }
  document.getElementById("normal_totalPrice").innerHTML = price_sum + "";
}
function Dawn_product() {
  var price_sum = 0;
  for (var element of checkboxCollection_dawn) {
    var elePrice =
      element.parentNode.parentNode.children[5].firstElementChild.innerHTML;
    if (element.checked) {
      price_sum += parseInt(elePrice);
    }
  }

  document.getElementById("dawn_totalPrice").innerHTML = price_sum + "";
}
function allcheck_normal() {
  if (allcheckBox_normal.checked) {
    for (var element of checkboxCollection_normal) {
      element.checked = true;
    }
  } else {
    for (var element of checkboxCollection_normal) {
      element.checked = false;
    }
  }
  check_change();
}
function allcheck_dawn() {
  if (allcheckBox_dawn.checked) {
    for (var element of checkboxCollection_dawn) {
      element.checked = true;
    }
  } else {
    for (var element of checkboxCollection_dawn) {
      element.checked = false;
    }
  }
  check_change();
}
function lengthCheck() {
  if(checkboxCollection_normal.length==0) {
    document.getElementById('normal_totalPrice').innerHTML=0;
  }
  if(checkboxCollection_dawn.length==0) {
    document.getElementById('dawn_totalPrice').innerHTML=0;
  }
}
function selectDeleteNormal() {
  var list = document.querySelectorAll(".normalCheck");
  for (var element of list) {
    if (element.checked) {
      var parent = document.querySelector("#normal_tbody");
      parent.removeChild(element.parentElement.parentElement);
    }
  }
  check_change();
  lengthCheck();
}
function selectDeleteDawn() {
  var list = document.querySelectorAll(".dawnCheck");
  for (var element of list) {
    if (element.checked) {
      var parent = document.querySelector("#dawn_tbody");
      parent.removeChild(element.parentElement.parentElement);
    }
  }
  check_change();
  lengthCheck();
}
function moveToDawn() {
  var list = document.querySelectorAll(".normalCheck");
  for (var element of list) {
    if (element.checked) {
      var parent = document.querySelector("#normal_tbody");
      element.className = "dawnCheck";
      element.checked = false;
      var temp = element.parentElement.parentElement;
      parent.removeChild(temp);
      document.getElementById("dawn_tbody").appendChild(temp);
    }
  }
  check_change();
  lengthCheck();
}
function moveToNormal() {
  var list = document.querySelectorAll(".dawnCheck");
  for (var element of list) {
    if (element.checked) {
      var parent = document.querySelector("#dawn_tbody");
      element.className = "normalCheck";
      element.checked = false;
      var temp = element.parentElement.parentElement;
      parent.removeChild(temp);
      document.getElementById("normal_tbody").appendChild(temp);
    }
  }
  check_change();
  lengthCheck();
}
